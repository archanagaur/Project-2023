function calc() {
    var inr_value = document.getElementById("input1").value;
    document.querySelector('#msg').innerText ='';
    if (inr_value.length <= 0) {
        document.querySelector('#msg').innerText = 'Enter a Value!';
        return;
    }
    inr_value=Number(inr_value);
    console.log(inr_value);
    if (isNaN(inr_value)) {
        console.log('hi');
        document.querySelector('#msg').innerText = 'Enter a Number!';
        return;
    }

        var doll_value = inr_value * 82.73;
        var euro_value = inr_value * 87.94;
        var yen_value = inr_value * 0.63;
        document.getElementById("doll").innerHTML = "DOLLAR: " + doll_value;
        document.getElementById("euro").innerHTML = "EURO: " + euro_value;
        document.getElementById("yen").innerHTML = "YEN: " + yen_value;

}
