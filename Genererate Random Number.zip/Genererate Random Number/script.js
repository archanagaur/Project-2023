function change_color()
{
    let min='1';
    let add_min='0';
    let max='9'
    let add_max='9';
    document.getElementById('result').style.background='linear-gradient(180deg,rgb(110, 110, 110),rgb(173, 173, 173),rgb(117, 117, 117))';
    document.getElementById('result').style.boxShadow='0 10px 25px rgb(166, 166, 166)';
    document.getElementById('result').style.border='1px solid red';
    var val=document.getElementById('others').value;
    console.log(`value:${val}`)

    for(let i=0;i<val-1;i++)
    {
        min=min+add_min;
         max=max+add_max
    }
    min=Number(min);
    max=Number(max);
    console.log(`min:${min}`)
    console.log(`max:${max}`)

    var ran=Math.floor(Math.random()*(max-min)+min);
    console.log(`random:${ran}`)
    document.getElementById('result').innerHTML=`Generated Number : ${ran}`;
    
}


function generate_number(min,max)
{
    document.getElementById('result').style.background='linear-gradient(180deg,rgb(110, 110, 110),rgb(173, 173, 173),rgb(117, 117, 117))';
    document.getElementById('result').style.boxShadow='0 10px 25px rgb(166, 166, 166)';
    document.getElementById('result').style.border='1px solid inset';
    var ran=Math.floor(Math.random()*(max-min)+min);
    document.getElementById('result').innerHTML=`Generated Number : ${ran}`;
}
// '#404040'
