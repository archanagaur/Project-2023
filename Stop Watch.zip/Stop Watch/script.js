
let Count_milisec = 0;
let Count_sec = 0;
let Count_min = 0;
let Count_hr = 0;

let record_arr=[];

function count() {
    let hrTag = document.getElementById('hr');
    let minTag = document.getElementById('min');
    let secTag = document.querySelector('#sec');
    let milisecTag = document.querySelector('#milisec');
    Count_milisec++;
    if (Count_milisec <= 500) {
        milisecTag.innerText = Count_milisec;
    }
    else {
        Count_milisec = 0;
        milisecTag.innerText = Count_milisec;
        Count_sec++;
        if (Count_sec <= 60) {
            secTag.innerText = Count_sec;
        }
        else {
            Count_sec = 0;
            secTag.innerText = Count_sec;
            Count_min++;
            if(Count_min<=60)
            {
                minTag.innerText = Count_min;
            }
            else
            {
                Count_min=0;
                Count_hr++
                hrTag.innerText = Count_hr;
            }
        }
    }
}



function start() {
    document.querySelector('#start_btn').style.opacity='0.3';
    document.querySelector('#stop').style.opacity='1';
    let res = setInterval(count, 1);
    let stop_btn = document.querySelector('#stop');
    stop_btn.addEventListener('click', () => {
        document.querySelector('#stop').style.opacity='0.3';
        document.querySelector('#start_btn').innerText='Resume';
        document.querySelector('#start_btn').style.opacity='1';
        clearInterval(res);
    })
    let restart_btn = document.querySelector('#restart');
    restart_btn.addEventListener('click', () => {
        document.querySelector('#start_btn').innerText='Start';
        document.querySelector('#stop').style.opacity='1';
        clearInterval(res);
        document.getElementById('min').innerText = '00';
        document.querySelector('#sec').innerText = '00';
        document.querySelector('#milisec').innerText = '00';
    })
}


function store() {
    document.querySelector('.display_lap').style.display='block'
    let display_res = `${Count_min}:${Count_sec}:${Count_milisec}`
    record_arr.unshift(display_res)
    let res=record_arr.map((value,index)=>
    {
        return `<h3>${index+1})  ${value}</h3>`;
    })
    let new_res=res.join(' ');
    document.querySelector('#display').innerHTML = new_res;
}

