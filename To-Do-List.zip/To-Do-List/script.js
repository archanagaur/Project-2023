
// script code

let arr = [];
// Function to add a task

function addObj() {

    let task = document.querySelector('#task_obj').value;
    if (task.length == 0) {
        document.querySelector('#message').style.display = 'block';
        document.querySelector('#message').innerHTML = 'Enter your task!'
        return;
    }
    document.querySelector('#message').style.display = 'none';

    //    Id creation
    let id_part1 = String(Math.trunc(Math.random() * 1000));
    let d = new Date();
    let dd = String(d.getTime());
    let id_part2 = dd.slice(9, 13);
    let id = 'Taskid' + id_part1 + id_part2;

    let obj =
    {
        taskID: id,
        taskName: task
    }
    arr.unshift(obj);
    Display();
}


// Function to display tasks

function Display() {
    let date = new Date().toLocaleDateString();
    let time = new Date().toLocaleTimeString();
    document.querySelector('#task_obj').value = '';
    // console.log(arr, arr.length);
    if (arr.length === 0) {
        document.querySelector('.container2').style.display = 'none';
        return;
    }
    let res = arr.map((value, index) => {
        console.log(index,arr)
        return `<table>
                  <tr>
                    <td> <div class="animate__animated animate__backInDown" id="task_box"><h4  id="task">${index + 1}.  ${value.taskName}</h4><div> </td>
                    <td><span id="date_edit">Edit on:</span><span id="date_box">${date} ${time}</span </td>
                    <td> <button id="edit" class="btn bg-dark text-light" onclick="Edit(${index})">Edit</button></td>
                    <td> <button id="delete" onclick="Remove(${index})">❌</button> </td>
                  </tr>
                  </table>
                  <table>
                  <tr>
                    <td> <input type="text" id="edit_task"> </td>
                    <td> <button onclick="Update(${index})" id="Update_task">Done</button></td>
                    <td> <button onclick="Display()" id="cancel_btn">Cancel</button></td>
                    <td> <label id="head1">T</label></td>
                    <td><input type="color" id="color_selector_text" placeholder="Enter task here to update!"> </td>
                    <td> <label id="head2">BG</label></td>
                    <td><input type="color" id="color_selector_Bg"> </td>
                  </tr>
                  <tr><td><span id='msg'>Enter the task to update!</span></td></tr>
                </table>`
    })
    document.querySelector('.container2').style.display = 'block';
    let result_arr = res.join(' ');
    document.querySelector('#display_task').innerHTML = result_arr;


    // Function to change the task text color

    let color_tag_text = document.querySelector('#color_selector_text');

    color_tag_text.addEventListener('input', function () {
        let color_code = document.querySelector('#color_selector_text').value;
        document.querySelector('#task').style.color = color_code;
    })

    // Function to change the task background color

    let color_tag_Bg = document.querySelector('#color_selector_Bg');

    color_tag_Bg.addEventListener('input', function () {
        let color_code = document.querySelector('#color_selector_Bg').value;
        document.querySelector('#task').style.backgroundColor = color_code;
    })

}

// Function to Delete tasks

function Remove(arr_index) {

    let res = arr.filter((value, index) => {
        if (index === arr_index) {
            arr.splice(arr_index, 1);
        }
    })
    Display();
}


// Function to Display Update Elements

function Edit() {
    document.querySelector('#edit_task').style.display = 'block';
    document.querySelector('#Update_task').style.display = 'block';
    document.querySelector('#color_selector_text').style.display = 'block';
    document.querySelector('#color_selector_Bg').style.display = 'block';
    document.querySelector('#cancel_btn').style.display = 'block';
    document.querySelector('#head1').style.display = 'block';
    document.querySelector('#head2').style.display = 'block';
    document.querySelector('#edit_task').placeholder = 'Enter task here to update!'

}

// Function to Update the task

function Update(arr_index) {
    let updated_task = document.querySelector('#edit_task').value;
    if (updated_task.length === 0) {
        document.querySelector('#msg').style.display = 'block';
        return;
    }
    let res = arr.filter((value, index) => {
        // console.log(arr_index,index)
        if (index === arr_index) {
            // console.log(value.taskName)
            value.taskName = updated_task;
        }
    })
    Display();
}
